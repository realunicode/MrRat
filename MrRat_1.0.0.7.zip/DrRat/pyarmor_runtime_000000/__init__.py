# Pyarmor 9.1.2 (trial), 000000, 2025-04-04T15:35:01.565750
from .pyarmor_runtime import __pyarmor__
